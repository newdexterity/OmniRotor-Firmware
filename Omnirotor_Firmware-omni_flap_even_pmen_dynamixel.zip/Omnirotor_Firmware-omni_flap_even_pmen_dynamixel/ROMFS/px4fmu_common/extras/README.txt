px4fmuv3_bl.bin: Bootloader binary of the PX4 Bootloader
  (https://github.com/PX4/Bootloader)
  based on commit 184b813699a9cfd6f43a5a21556a06b4372baf5f
  for the target px4fmuv3_bl

